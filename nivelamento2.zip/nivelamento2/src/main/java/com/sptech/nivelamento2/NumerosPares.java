/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sptech.nivelamento2;

/**
 *
 * @author Aluno
 */
public class NumerosPares {
    public static void main(String[] args) {
        Integer count = 0;
        while(count < 41){
            if (count % 2 == 0) {
                System.out.println(count);
            }
            count++;
        }
    }
   
}
